import json,pprint

ground_truths = {'Red Line':(100,0),
				 'Blue Line':{'right': (125,0),'left': (75,0)},
				 'Goal Line':{'right': (189,0),'left': (11,0)},
				 'Center ice':(100,42.5),
				 'Neutral Faceoff Dot':{"['right', 'top']":(120,20.5),
				 						"['top', 'right']":(120,20.5),
				 						"['right', 'bottom']":(120,64.5),
				 						"['bottom', 'right']":(120,64.5),
				 						"['left', 'top']":(80,20.5),
				 						"['top', 'left']":(80,20.5),
				 						"['left', 'bottom']":(80,64.5),
				 						"['bottom', 'left']":(80,64.5)},
				 'Zone Faceoff Dot':{"['right', 'top']":(169,20.5),
				 					 "['top', 'right']":(169,20.5),
			 						 "['right', 'bottom']":(169,64.5),
			 						 "['bottom', 'right']":(169,64.5),
			 						 "['left', 'top']":(31,20.5),
			 						 "['top', 'left']":(31,20.5),
			 						 "['left', 'bottom']":(31,64.5),
			 						 "['bottom', 'left']":(31,64.5)},
			 	 'Goal Post':{"['right', 'top']":(189,39.5),
			 	 			  "['top', 'right']":(189,39.5),
	 						  "['right', 'bottom']":(189,45.5),
	 						  "['bottom', 'right']":(189,45.5),
	 						  "['left', 'top']":(11,39.5),
	 						  "['top', 'left']":(11,39.5),
	 						  "['left', 'bottom']":(11,45.5),
	 						  "['bottom', 'left']":(11,45.5)},
	 			 'Center Blue Line':{'right': (125,42.5),'left': (75,42.5)},
	 			 'Center Goal Line':{'right': (189,42.5),'left': (11,42.5)},
}

def init():
	file = open('data.json','r')
	dataset = []
	for line in file:
		s = json.loads(line)
		for image in s:
			features = {}
			features['filename']=image['External ID']
			index = 0
			for label in image['Label']:
				#feature = image['Label'][label][0]
				if(image['Label'][label][0] not in ['right','left']):
					for feature in image['Label'][label]:
						if(label == 'side of ice'):
							#print(label,"|",image['Label'][label])
							continue
						desc = feature['side'][1] + " " + feature['side'][0] if len(feature['side'])==2 else feature['side']
						#print(label,desc,"|",ground_truths[label][str(feature['side'])],"|",(feature['geometry']['x'],feature['geometry']['y']))
						features[index] = {'truth':ground_truths[label][str(feature['side'])],'image':(feature['geometry']['x'],feature['geometry']['y']),'description':label+" "+desc}
						index+=1
			dataset.append(features)
	return dataset
			
			

if __name__ == '__main__':
	dataset = init()
	pp = pprint.PrettyPrinter(indent=4)
	pp.pprint(dataset)

