import numpy as np
imageA = np.zeros((2,2))
imageB = np.zeros((2,3))

imageA[:]=2
print('imageA:\n',imageA,'\n')

imageB[:]=3
print('imB:\n',imageB,'\n')

avgA = (300,300)
avgB = (299,301)



shift_x = avgA[0]-avgB[0]
shift_y = avgA[1]-avgB[1]
result = np.zeros((imageA.shape[1]+abs(shift_y),imageA.shape[0]+abs(shift_x)))
print(result.shape)
result[:,:]=-np.inf

right,shift_x = (abs(shift_x),0) if shift_x<0 else (0,shift_x) 
down,shift_y = (abs(shift_y),0) if shift_y<0 else (0,shift_y) 

result[shift_y:(imageA.shape[1]+shift_y),shift_x:(imageA.shape[0]+shift_x)]=np.where(result[shift_y:(imageA.shape[1]+shift_y),shift_x:(imageA.shape[0]+shift_x)]==-np.inf,imageA,result[shift_y:(imageA.shape[1]+shift_y),shift_x:(imageA.shape[0]+shift_x)])

result[down:(imageB.shape[1]+down),right:
(imageB.shape[0]+right)]=np.where(result[
	down:(imageB.shape[1]+down),
	right:
	(imageB.shape[0]+right)]==-np.inf,imageB,
	result[
	down:
	(imageB.shape[1]+down),
	right:(imageB.shape[0]+right)
	])
print('result after\n',result)